package 실습과;
interface InterEx2{
	void setName(String name);
	void setAge(int age);
	void setScore(double score);
	String getName();
	int getAge();
	double getScore();
}

class Data3 implements InterEx2{
	private String name;
	private int age;
	private double score;
	
	public void setName(String name) {this.name=name;}
	public void setAge(int age) { this.age= age;}
	public void setScore(double score) { this.score=score;}
	public String getName() { return name;}
	public int getAge() { return age;}
	public double getScore() { return score;}
	
}
public class AppEx2_3 extends Data3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AppEx2_3 std=new AppEx2_3();
		
		std.setName("박문각");
		std.setAge(30);
		std.setScore(45.5);
		
		System.out.print("이름: "+ std.getName()+"\n");
		System.out.print("나이: "+ std.getAge()+"\n");
		System.out.println("이름: "+ std.getScore());
	}

}
