package 실습과;

public class AppEx1_3 {

	public void eSwap(int d[]) {
		int temp;
		
		temp=d[0];
		d[0]=d[1];
		d[1]=temp;
		
		System.out.println("교체된 데이터1 : x="+ d[0]+ ", y="+ d[1]); //교체
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AppEx1_3 k= new AppEx1_3();
		
		int data[]= new int[2];
		data[0]=10;
		data[1]=20;
		
		System.out.println("원본 데이터: x=" + data[0]+", y="+ data[1]);
		 
		k.eSwap(data);
		System.out.println("교체된 데이터2: x="+ data[0]+ ", y="+ data[1]);
		

	}

}
