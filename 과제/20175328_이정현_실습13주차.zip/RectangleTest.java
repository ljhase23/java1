package p201126;
class ShapeRec{
	protected int x,y;
	void print() {
		System.out.println("x��ǥ : " + x + "y��ǥ : " + y);
	}
}
public class RectangleTest extends ShapeRec{
	int width, height;
	
	double calcArea() {
		return width * height;
	}
	void draw() {
		print(); //protected print�Է�
		System.out.println("(" + x + "," + y + ") ��ġ�� " + "���� : " + width + "���� : " + height);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RectangleTest k = new RectangleTest();
		
		k.x=10;
		k.y=20;
		k.width = 100;
		k.height = 50;
		k.draw();
		System.out.println("�簢���� ���� : " + k.calcArea());

	}

}
