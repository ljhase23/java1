package p201126;

public class SportCarTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SportCar obj = new SportCar();
		
		obj.speed = 10;
		obj.setSpeed(60);
		obj.setTurbo(true);
		

	}

}
