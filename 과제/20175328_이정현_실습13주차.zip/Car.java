package p201126;

public class Car {
	int speed;

	public void setSpeed(int speed) {
		// TODO Auto-generated method stub
		System.out.println("�Է� �� speed : " + this.speed);
		this.speed = speed;
		System.out.println("�Է� �� speed : " + this.speed);

	}

}
