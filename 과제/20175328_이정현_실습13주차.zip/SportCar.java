package p201126;

public class SportCar extends Car {
	boolean turbo;

	public void setTurbo(boolean flag) {
		// TODO Auto-generated method stub
		turbo = flag;
		System.out.println("turbo : " + turbo);

	}

}
