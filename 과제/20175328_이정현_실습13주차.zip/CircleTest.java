package p201126;

class ShapeCr{
	int x,y;
}
class Circle extends ShapeCr{
	int radius;
	
	public Circle(int radius) {
		this.radius = radius;
		x = 0;
		y = 0;
	}
	double calcArea() {
		return 3.14 * radius * radius;
	}
}

public class CircleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle obj = new Circle(10);
		System.out.println("���� �߽� : (" + obj.x + ","+ obj.y +")");
		System.out.println("���� ���� : " + obj.calcArea());
	}

}
