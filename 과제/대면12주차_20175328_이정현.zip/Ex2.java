package p201116;
import java.util.Scanner;
public class Ex2 {
	Scanner sc=new Scanner(System.in);
		int x;
		char c;
		public Ex2() {
			System.out.print("��ȣ�� �Է��ϼ��� : ");
			c=sc.next().charAt(0);			
			System.out.print("�ݺ��� Ƚ���� �Է��ϼ��� : ");
			x=sc.nextInt();
		}
		void prt() {
			for(int i=0; i<x; i++)
			{
				System.out.print(c);
			}
			System.out.println(" ("+x+")");
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex2 k=new Ex2();
		k.prt();
	}

}