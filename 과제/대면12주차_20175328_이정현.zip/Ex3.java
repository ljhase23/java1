package p201116;
import java.util.Scanner;
public class Ex3 {
	Scanner sc= new Scanner(System.in);

	int x;
	char y;
	static int cnt=1;
	void input()
	{
		System.out.print("��ȣ�� �Է��ϼ��� : ");
		y=sc.next().charAt(0);
		System.out.print("�ݺ��� Ƚ���� �Է��ϼ��� : ");
		x=sc.nextInt();
	}
	void input (char y)
	{
		this.y=y;
		x=10;

	}
	void input(char y,int x)
	{
		this.y=y;
		this.x=x;
	}
	void prt()
	{
		System.out.print("["+ cnt++ +"]��� ��� : ");
		for(int i=0;i<x; i++)
		{
			System.out.print(y);
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex3 k= new Ex3();
		Ex3 k1=new Ex3();
		Ex3 k2=new Ex3();
		
		k.input();
		k.prt();
		
		k1.input('#');
		k1.prt();
		
		k2.input('@',5);
		k2.prt();
	}
}