package p201116;

public class Exam1 {	
		char a;
		int y;
	public Exam1(char x, int z) {
		a=x;
		y=z;
	}
	public Exam1(char c) {
		a=c;
		y=10;
	}
	void prt()
	{
		for(int i=0; i<y; i++)
		{
			System.out.print(a);
		}
		System.out.println(" ("+y+")");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exam1 k=new Exam1('#');
		Exam1 k1=new Exam1('@',5);
		k.prt();
		k1.prt();
		System.out.println();
	}
}