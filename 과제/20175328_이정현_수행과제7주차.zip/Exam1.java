package p201014;
import java.util.Scanner;

public class Exam1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("����� ���� �־��ּ��� : ");
		
		int [][] A = new int [2][3];
		int [][] B = new int[2][3];
		int [][] C = new int[2][3];
		
		System.out.print("A�� ��İ� : ");
		for(int i=0; i<2; i++) {
			for(int j=0; j<3; j++) {
				A[i][j] = (sc.nextInt());
			}
		}
		System.out.print("B�� ��İ� : ");
		for(int i=0; i<2; i++) {
			for(int j=0; j<3; j++) {
				B[i][j] = (sc.nextInt());
			}
		}
		for(int i=0;i<2;i++) {
			for(int j=0;j<3;j++) {
				C[i][j] = 2*(A[i][j])-3*(B[i][j]);
			}
		}
		sc.close();
		for(int i=0; i<2; i++) {
			for(int j=0; j<3; j++) {
				System.out.print(C[i][j]);
			}
			System.out.println();
		}
		
		
	
		
	}

}
