package p201028;
import java.util.Scanner;
public class Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		System.out.println("x�� ���� �Է� :");
		int x=sc.nextInt();
		System.out.println("y�� ���� �Է� :");
		int y =sc.nextInt();
		sc.close();
		
		int x20=1;
		int y17=1;
		
		for(int i=1;i<=20;i++) {
			x20*=x;
		}
		for(int i=1;i<=17;i++) {
			y17*=y;
		}
		int f=x20+y17+4*x+(-5*y)+10;
		System.out.println(f);

	}

}
