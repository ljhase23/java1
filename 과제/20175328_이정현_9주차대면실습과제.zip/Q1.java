package p201028;
import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		
		int a;
		double sum=0,avg=0;
		System.out.println("�迭�� ũ�⸦ �����ض�!");
		a = sc.nextInt();
		int x[];
		x = new int[a];
		
		for(int i=0;i<x.length;i++) {
			x[i]= sc.nextInt();
			sum+=x[i];
		}
		sc.close();
		avg=sum/a;
			System.out.println("�迭�� ����" + sum);
			System.out.println("�迭�� �����" + avg);

	}

}
